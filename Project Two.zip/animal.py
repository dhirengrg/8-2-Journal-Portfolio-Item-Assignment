from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD"""
    def __init__(self, username, password):
        self.client = MongoClient('mongodb://%s:%s@localhost:48513/AAC' %(username, password))
        self.database = self.client['AAC']
   #create method C in CRUD
    def create(self, data):
        if data is not None:
            if data:
                self.database.animals.insert_one(data)
                return True
            else:
                return False
         #read method R in CRUD
    def read(self, search):
        if search is not None:
            if search:
                searchResult = self.database.animals.find(search)
                return searchResult
            else:
                exception = "Nothing to search, because search parameter is empty"
                return exception
        #update method U in CRUD
    def update(self, save):
        if save is not None:
            if save:
                saveResult = self.database.animals.insert(save)
                return saveResult
            else:
                exception = "Nothing to search, because search parameter is empty"
                return exception
            #delete method D in CRUD
    def delete(self, remove):
        if remove is not None:
            if remove:
                removeResult = self.database.animals.delete_one(remove)
                return removeResult
            else:
                exception = "Nothing to search, because search parameter is empty"
                return exception
            
        